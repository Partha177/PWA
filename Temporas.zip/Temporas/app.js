const bodyParser = require("body-parser");
const express = require("express");
const app = express();
const port = 3000;

// We want to use JSON to send post request to our application
app.use(bodyParser.json());

// We tell express to serve the folder public as static content
app.use(express.static("public"));
app.get("/public");

// app.get("*", function(req, res) {
//   res.render("index.html");
// });

app.listen(port, "0.0.0.0", () => console.log(`Listening on port ${port}!`));
